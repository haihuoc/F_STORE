/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Bùi Tuấn
 */
public class Connection {
    private static final String connectUrl = "jdbc:sqlserver://localhost:1433;user=sa;password=1234;databaseName=QLMT;encrypt=false;";
    public static java.sql.Connection getconConnection()
    {
        java.sql.Connection con = null;
        try {
            con = DriverManager.getConnection(connectUrl);
            System.out.println("ok");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("fail");
        }
        return con;
    }
    public static void main(String[] args) {
        getconConnection();
    }
}
